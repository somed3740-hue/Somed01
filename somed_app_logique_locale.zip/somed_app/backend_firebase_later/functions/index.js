const { onDocumentCreated, onDocumentUpdated } = require('firebase-functions/v2/firestore');
const { onSchedule } = require('firebase-functions/v2/scheduler');
const admin = require('firebase-admin');
admin.initializeApp();
const db = admin.firestore();

const android = {
  priority: 'high',
  notification: { channelId: 'ride_requests', sound: 'new_order_alert' },
};

async function tokenOf(uid) {
  const u = await db.collection('users').doc(uid).get();
  return u.get('fcmToken');
}

// 1) Nouvelle demande -> notifier tous les chauffeurs en ligne
exports.notifyDrivers = onDocumentCreated('rides/{id}', async (event) => {
  const ride = event.data.data();
  const drivers = await db.collection('drivers').where('online', '==', true).get();
  const tokens = (await Promise.all(drivers.docs.map((d) => tokenOf(d.id)))).filter(Boolean);
  if (!tokens.length) return;
  await admin.messaging().sendEachForMulticast({
    tokens,
    notification: { title: 'Nouvelle course', body: `${ride.pickup} → ${ride.destination}` },
    data: { rideId: event.params.id, type: 'new_ride' },
    android,
  });
});

// 2) Changement de statut -> notifier le client
const MESSAGES = {
  accepted: 'Un chauffeur a accepté votre course',
  arrived: 'Votre chauffeur est arrivé',
  ongoing: 'Votre course a démarré',
  completed: 'Course terminée, merci !',
};
exports.notifyRider = onDocumentUpdated('rides/{id}', async (event) => {
  const before = event.data.before.data();
  const after = event.data.after.data();
  if (before.status === after.status || !MESSAGES[after.status]) return;
  const token = await tokenOf(after.riderId);
  if (!token) return;
  await admin.messaging().send({
    token,
    notification: { title: 'SOMED', body: MESSAGES[after.status] },
    data: { rideId: event.params.id, type: 'status' },
    android,
  });
});

// 3) Nettoyage automatique : demandes sans chauffeur après 10 min -> annulées
exports.expireRequests = onSchedule('every 5 minutes', async () => {
  const limit = admin.firestore.Timestamp.fromMillis(Date.now() - 10 * 60 * 1000);
  const old = await db.collection('rides')
    .where('status', '==', 'requested').where('createdAt', '<', limit).get();
  const batch = db.batch();
  old.docs.forEach((d) => batch.update(d.ref, { status: 'cancelled', cancelReason: 'timeout' }));
  await batch.commit();
});
