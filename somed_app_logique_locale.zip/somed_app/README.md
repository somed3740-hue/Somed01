# SOMED : logique locale (Firebase laissé pour plus tard)

Cette version fonctionne **sans serveur** : un dépôt local (`lib/services/repository.dart`) joue le rôle du backend
(création de course, recherche de chauffeur, offres de 25 s, acceptation unique, étapes, expiration).

## Installation
1. `flutter create --org com.votreorg --project-name somed .` (sans écraser `lib/`, `assets/`, `pubspec.yaml`)
2. Copier `android_overlay/app/src/main/res/` vers `android/app/src/main/res/` (icônes, son d'alerte).
3. Appliquer `android_overlay/MANIFEST_ADDITIONS.xml` (permissions, VOTRE clé Google Maps, liens).
4. `minSdk = 23` dans `android/app/build.gradle(.kts)`, et activer le "core library desugaring" si Gradle le demande
   (requis par flutter_local_notifications).
5. `flutter pub get && flutter run`

## Tester seul (un téléphone)
- Créez un profil avec les rôles Passager + Chauffeur (+ Entreprise).
- Mode Passager : choisissez la destination (« Définir sur la carte »), Commander.
- Le « chauffeur démo » (Profil) accepte au bout de 7 s et déroule la course. Désactivez-le, passez en mode Chauffeur,
  « En ligne », et acceptez vous-même : une seule personne obtient la course.
- Pour tester à deux téléphones réels, il faut un backend partagé : étape Firebase (ci-dessous).

## Ce qui marche
Profil local, 3 modes (switch), 3 langues (FR/EN/AR), carte Google, position, « définir sur la carte », prix selon
le véhicule, paiement espèces/carte/portefeuille (simulé), notifications locales avec son, annonces vocales,
SOS, évaluation, historique, facture PDF, tableau de bord entreprise, liens `/d/<id>`.

## Ce qui est simulé ou manque
- Carte : trajet en ligne droite, distance estimée (brancher l'API Routes plus tard).
- Stripe : renseigner `stripePublishableKey` et `stripeBackendUrl` dans `lib/core/config.dart` ; il faut un petit serveur
  `POST /create-payment-intent` (la clé secrète reste sur le serveur). Sans cela, le paiement est simulé.
- Pas de notification quand l'application est fermée, pas de synchronisation entre téléphones, pas de connexion
  Google/SMS : c'est le rôle de Firebase (dossier `backend_firebase_later/` : règles, index, fonctions déjà prêts).
- Mode « professionnel » de l'original : non reproduit.

## Brancher Firebase plus tard
Créer `FirebaseRepository` avec les mêmes méthodes que `LocalRepository` (create, accept, advance, cancel, rate, offers),
ajouter Auth (Google, SMS) et FCM, puis déployer `backend_firebase_later/`.
