import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../core/config.dart';
import '../models/models.dart';

Future<void> shareInvoice(Ride r, String clientName) async {
  final doc = pw.Document();
  doc.addPage(pw.Page(
    build: (_) => pw.Column(crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
      pw.Text('SOMED - Facture', style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
      pw.SizedBox(height: 16),
      pw.Text('N° ${r.id}'),
      pw.Text('Date : ${r.createdAt.toLocal().toString().substring(0, 16)}'),
      pw.Text('Client : $clientName'),
      pw.Text('Chauffeur : ${r.driverName ?? '-'}'),
      pw.SizedBox(height: 12),
      pw.Text('Départ : ${r.pickup.address}'),
      pw.Text('Destination : ${r.dest.address}'),
      pw.Text('Distance : ${r.km.toStringAsFixed(1)} km'),
      pw.Text('Paiement : ${r.pay.name}${r.paid ? ' (payé)' : ''}'),
      pw.Divider(),
      pw.Text('Total : ${r.price.toStringAsFixed(2)} $currency',
          style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold)),
    ]),
  ));
  await Printing.sharePdf(bytes: await doc.save(), filename: 'facture_${r.id}.pdf');
}
