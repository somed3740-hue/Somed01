import 'dart:math';

import '../models/models.dart';

class Pricing {
  static const _base = {VehicleType.eco: 10.0, VehicleType.comfort: 15.0, VehicleType.moto: 6.0};
  static const _perKm = {VehicleType.eco: 4.0, VehicleType.comfort: 6.0, VehicleType.moto: 2.5};
  static const _min = {VehicleType.eco: 15.0, VehicleType.comfort: 25.0, VehicleType.moto: 10.0};

  static double estimate(VehicleType v, double km) =>
      max(_min[v]!, _base[v]! + _perKm[v]! * km).roundToDouble();

  /// Distance à vol d'oiseau x 1,3 (approximation de la route).
  /// Plus tard : remplacer par l'API Routes de Google.
  static double km(Place a, Place b) {
    const r = 6371.0;
    double rad(double d) => d * pi / 180;
    final dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
    final h = pow(sin(dLat / 2), 2) + cos(rad(a.lat)) * cos(rad(b.lat)) * pow(sin(dLng / 2), 2);
    return 2 * r * asin(sqrt(h)) * 1.3;
  }
}
