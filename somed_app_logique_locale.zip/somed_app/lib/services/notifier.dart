import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import '../models/models.dart';

/// Notifications LOCALES + sons. Les vraies notifications push (app fermée)
/// viendront avec Firebase Cloud Messaging.
class Notifier {
  static final _p = FlutterLocalNotificationsPlugin();
  static final _audio = AudioPlayer();
  static void Function(String rideId)? onOpen;

  static const _sound = RawResourceAndroidNotificationSound('new_order_alert');

  static Future<void> init() async {
    await _p.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('ic_notification')),
      onDidReceiveNotificationResponse: (r) {
        if (r.payload != null && r.payload!.isNotEmpty) onOpen?.call(r.payload!);
      },
    );
    final a = _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();
    await a?.requestNotificationsPermission();
    await a?.createNotificationChannel(const AndroidNotificationChannel(
      'ride_requests', 'Demandes de course',
      importance: Importance.max, sound: _sound,
    ));
  }

  static Future<void> show(String title, String body, String rideId) {
    return _p.show(
      DateTime.now().millisecondsSinceEpoch ~/ 1000, title, body,
      const NotificationDetails(
        android: AndroidNotificationDetails(
          'ride_requests', 'Demandes de course',
          importance: Importance.max, priority: Priority.high, sound: _sound,
        ),
      ),
      payload: rideId,
    );
  }

  static Future<void> play(String file) async {
    try {
      await _audio.stop();
      await _audio.play(AssetSource('sounds/$file'));
    } catch (_) {}
  }

  static Future<void> voice(RideStatus s) async {
    switch (s) {
      case RideStatus.arrived:
        return play('voice_arrived.mp3');
      case RideStatus.ongoing:
        return play('voice_trip_started.mp3');
      case RideStatus.completed:
        return play('voice_trip_completed.mp3');
      default:
        return;
    }
  }
}
