import 'dart:convert';

import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;

import '../core/config.dart';
import '../models/models.dart';

abstract class PaymentService {
  Future<bool> pay(Ride r);
}

/// Paiement simulé (aucun argent réel) tant que Stripe n'est pas configuré.
class SimulatedPayment implements PaymentService {
  @override
  Future<bool> pay(Ride r) async => true;
}

/// Stripe : nécessite un petit serveur qui crée le PaymentIntent
/// (POST {stripeBackendUrl}/create-payment-intent -> {"clientSecret": "..."}).
/// La clé secrète Stripe reste sur ce serveur, jamais dans l'application.
class StripePayment implements PaymentService {
  @override
  Future<bool> pay(Ride r) async {
    try {
      final res = await http.post(
        Uri.parse('$stripeBackendUrl/create-payment-intent'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'amount': (r.price * 100).round(),
          'currency': currency.toLowerCase(),
          'rideId': r.id,
        }),
      );
      final secret = jsonDecode(res.body)['clientSecret'] as String;
      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: secret,
          merchantDisplayName: 'SOMED',
        ),
      );
      await Stripe.instance.presentPaymentSheet();
      return true;
    } catch (_) {
      return false;
    }
  }
}

PaymentService buildPayment() =>
    (stripePublishableKey.isEmpty || stripeBackendUrl.isEmpty) ? SimulatedPayment() : StripePayment();
