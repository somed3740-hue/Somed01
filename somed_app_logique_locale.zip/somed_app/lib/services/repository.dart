import 'dart:async';
import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';

/// Dépôt de courses LOCAL (sur le téléphone). Il joue le rôle du serveur :
/// création, recherche de chauffeur (dispatch), offres, acceptation, étapes.
/// Plus tard, remplacez-le par une version Firebase qui garde les mêmes méthodes.
class LocalRepository extends ChangeNotifier {
  final List<Ride> rides = [];
  late SharedPreferences _p;
  void Function(AppMode target, String title, String body, String rideId)? onEvent;
  bool Function() botEnabled = () => true;
  final _timers = <String, List<Timer>>{};

  Future<void> load(SharedPreferences p) async {
    _p = p;
    final raw = p.getString('rides');
    if (raw != null) {
      for (final j in jsonDecode(raw) as List) {
        final r = Ride.fromJson(j as Map<String, dynamic>);
        if (!r.isFinal) r.status = RideStatus.expired; // courses interrompues par un redémarrage
        rides.add(r);
      }
    }
  }

  void _save() {
    _p.setString('rides', jsonEncode(rides.map((r) => r.toJson()).toList()));
    notifyListeners();
  }

  Ride? byId(String id) {
    for (final r in rides) {
      if (r.id == id) return r;
    }
    return null;
  }

  void _later(String id, int seconds, VoidCallback f) =>
      (_timers[id] ??= []).add(Timer(Duration(seconds: seconds), f));

  void _stop(String id) {
    for (final t in _timers.remove(id) ?? <Timer>[]) {
      t.cancel();
    }
  }

  Ride create({
    required String riderId, required Place pickup, required Place dest,
    required VehicleType vehicle, required PayMethod pay,
    required double km, required double price, required bool business,
  }) {
    final r = Ride(
      id: DateTime.now().millisecondsSinceEpoch.toString(), riderId: riderId,
      pickup: pickup, dest: dest, vehicle: vehicle, pay: pay, km: km, price: price,
      business: business, createdAt: DateTime.now(),
    );
    rides.insert(0, r);
    _save();
    _dispatch(r);
    return r;
  }

  // Recherche (2 s) -> offre aux chauffeurs (25 s) -> acceptée ou expirée.
  void _dispatch(Ride r) {
    _later(r.id, 2, () {
      if (r.status != RideStatus.searching) return;
      r.status = RideStatus.offered;
      r.offerExpiresAt = DateTime.now().add(const Duration(seconds: 25));
      _save();
      onEvent?.call(AppMode.driver, 'Nouvelle course', '${r.pickup.address} → ${r.dest.address}', r.id);
      if (botEnabled()) {
        _later(r.id, 7, () => accept(r.id, 'bot', 'Chauffeur démo'));
      }
      _later(r.id, 25, () {
        if (r.status == RideStatus.offered) {
          r.status = RideStatus.expired;
          _save();
          onEvent?.call(AppMode.rider, 'SOMED', 'Aucun chauffeur disponible', r.id);
        }
      });
    });
  }

  /// Un seul chauffeur peut obtenir la course.
  bool accept(String id, String driverId, String driverName) {
    final r = byId(id);
    if (r == null || r.status != RideStatus.offered) return false;
    r.status = RideStatus.accepted;
    r.driverId = driverId;
    r.driverName = driverName;
    r.offerExpiresAt = null;
    _save();
    onEvent?.call(AppMode.rider, 'SOMED', '$driverName a accepté votre course', id);
    if (driverId == 'bot') {
      _later(id, 6, () => advance(id, RideStatus.arrived));
      _later(id, 12, () => advance(id, RideStatus.ongoing));
      _later(id, 22, () => advance(id, RideStatus.completed));
    }
    return true;
  }

  void advance(String id, RideStatus s) {
    final r = byId(id);
    if (r == null || r.isFinal) return;
    r.status = s;
    if (s == RideStatus.completed && r.pay == PayMethod.cash) r.paid = true;
    _save();
    const msg = {
      RideStatus.arrived: 'Votre chauffeur est arrivé',
      RideStatus.ongoing: 'Votre course a démarré',
      RideStatus.completed: 'Course terminée, merci !',
    };
    final m = msg[s];
    if (m != null) onEvent?.call(AppMode.rider, 'SOMED', m, id);
  }

  void cancel(String id) {
    final r = byId(id);
    if (r == null || r.isFinal) return;
    r.status = RideStatus.cancelled;
    _stop(id);
    _save();
  }

  void rate(String id, int stars) {
    byId(id)?.rating = stars;
    _save();
  }

  void markPaid(String id) {
    byId(id)?.paid = true;
    _save();
  }

  List<Ride> offers(Set<String> hidden) => rides
      .where((r) =>
          r.status == RideStatus.offered &&
          (r.offerExpiresAt?.isAfter(DateTime.now()) ?? false) &&
          !hidden.contains(r.id))
      .toList();
}
