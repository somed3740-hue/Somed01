import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/models.dart';
import '../services/notifier.dart';
import '../services/payment.dart';
import '../services/repository.dart';

final app = AppState();

class AppState extends ChangeNotifier {
  late SharedPreferences prefs;
  AppUser? user;
  String lang = 'fr';
  bool demoBot = true;
  bool driverOnline = false;
  final repo = LocalRepository();
  late PaymentService payment;

  Future<void> load() async {
    prefs = await SharedPreferences.getInstance();
    lang = prefs.getString('lang') ?? 'fr';
    demoBot = prefs.getBool('bot') ?? true;
    final u = prefs.getString('user');
    if (u != null) user = AppUser.fromJson(jsonDecode(u));
    await repo.load(prefs);
    repo.botEnabled = () => demoBot;
    repo.onEvent = (target, title, body, id) {
      final u = user;
      if (u == null || u.activeMode != target) return;
      if (target == AppMode.driver && !driverOnline) return;
      Notifier.show(title, body, id);
    };
    payment = buildPayment();
  }

  void _saveUser() {
    prefs.setString('user', jsonEncode(user!.toJson()));
    notifyListeners();
  }

  void signIn(String name, String phone, Set<AppMode> roles) {
    user = AppUser(
      id: 'u${DateTime.now().millisecondsSinceEpoch}', name: name, phone: phone,
      roles: roles, activeMode: roles.first,
    );
    _saveUser();
  }

  void switchMode(AppMode m) {
    user!.activeMode = m;
    _saveUser();
  }

  void setLang(String l) {
    lang = l;
    prefs.setString('lang', l);
    notifyListeners();
  }

  void setBot(bool v) {
    demoBot = v;
    prefs.setBool('bot', v);
    notifyListeners();
  }

  void setOnline(bool v) {
    driverOnline = v;
    notifyListeners();
  }

  void signOut() {
    prefs.remove('user');
    user = null;
    driverOnline = false;
    notifyListeners();
  }
}
