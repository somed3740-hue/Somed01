// Réglages à modifier. Rien de secret ici.
const currency = 'MAD';
const defaultLat = 33.5731; // position par défaut si le GPS est refusé
const defaultLng = -7.5898;
const commissionRate = 0.20; // part de la plateforme
const emergencyNumber = '112'; // numéro SOS à adapter à votre pays

// Stripe : laisser vide tant que le serveur n'existe pas (paiement simulé).
const stripePublishableKey = ''; // pk_test_...
const stripeBackendUrl = ''; // https://.../ (voir README)
