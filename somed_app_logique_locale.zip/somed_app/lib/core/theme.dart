import 'package:flutter/material.dart';

const somedYellow = Color(0xFFFFEB00);
const somedBlack = Color(0xFF111111);

ThemeData _theme(Brightness b) {
  final dark = b == Brightness.dark;
  return ThemeData(
    useMaterial3: true,
    brightness: b,
    colorScheme: ColorScheme.fromSeed(seedColor: somedYellow, brightness: b).copyWith(
      primary: dark ? somedYellow : somedBlack,
      onPrimary: dark ? Colors.black : somedYellow,
    ),
    appBarTheme: AppBarTheme(
      backgroundColor: dark ? somedBlack : somedYellow,
      foregroundColor: dark ? somedYellow : Colors.black,
    ),
    inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
  );
}

final lightTheme = _theme(Brightness.light);
final darkTheme = _theme(Brightness.dark);
