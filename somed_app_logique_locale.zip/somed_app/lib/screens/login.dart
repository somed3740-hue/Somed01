import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../models/models.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _roles = <AppMode>{AppMode.rider};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SOMED')),
      body: ListView(padding: const EdgeInsets.all(24), children: [
        Image.asset('assets/images/app_logo.png', height: 90),
        const SizedBox(height: 24),
        TextField(controller: _name, decoration: InputDecoration(labelText: t('name'))),
        const SizedBox(height: 12),
        TextField(
            controller: _phone,
            keyboardType: TextInputType.phone,
            decoration: InputDecoration(labelText: t('phone'))),
        const SizedBox(height: 16),
        Text(t('roles')),
        Wrap(spacing: 8, children: [
          for (final m in AppMode.values)
            FilterChip(
              label: Text(t(m.name)),
              selected: _roles.contains(m),
              onSelected: (v) => setState(() => v ? _roles.add(m) : _roles.remove(m)),
            ),
        ]),
        const SizedBox(height: 16),
        FilledButton(
          onPressed: () {
            if (_name.text.trim().isEmpty || _roles.isEmpty) return;
            app.signIn(_name.text.trim(), _phone.text.trim(), _roles);
          },
          child: Text(t('continue')),
        ),
        const SizedBox(height: 12),
        Text(t('authLater'), style: Theme.of(context).textTheme.bodySmall),
      ]),
    );
  }
}
