import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../core/strings.dart';
import '../models/models.dart';

Future<Place> placeAt(LatLng p) async {
  try {
    final m = await placemarkFromCoordinates(p.latitude, p.longitude);
    final x = m.first;
    final parts = [x.street, x.locality].where((e) => e != null && e.isNotEmpty).join(', ');
    if (parts.isNotEmpty) return Place(parts, p.latitude, p.longitude);
  } catch (_) {}
  return Place('${p.latitude.toStringAsFixed(5)}, ${p.longitude.toStringAsFixed(5)}', p.latitude, p.longitude);
}

/// "Définir sur la carte" : le pin reste au centre, l'utilisateur déplace la carte.
class MapPicker extends StatefulWidget {
  final LatLng initial;
  const MapPicker({super.key, required this.initial});
  @override
  State<MapPicker> createState() => _MapPickerState();
}

class _MapPickerState extends State<MapPicker> {
  late LatLng _center = widget.initial;
  Place? _place;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('setOnMap'))),
      body: Stack(alignment: Alignment.center, children: [
        GoogleMap(
          initialCameraPosition: CameraPosition(target: widget.initial, zoom: 16),
          myLocationEnabled: true,
          myLocationButtonEnabled: true,
          zoomControlsEnabled: false,
          onCameraMove: (c) => _center = c.target,
          onCameraIdle: () async {
            final p = await placeAt(_center);
            if (mounted) setState(() => _place = p);
          },
        ),
        const Padding(
          padding: EdgeInsets.only(bottom: 36),
          child: Icon(Icons.location_pin, size: 44, color: Colors.red),
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Card(
            margin: const EdgeInsets.all(16),
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Text(_place?.address ?? '…'),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: _place == null ? null : () => Navigator.pop(context, _place),
                    child: Text(t('confirm')),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}
