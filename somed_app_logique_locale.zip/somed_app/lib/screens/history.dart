import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/config.dart';
import '../core/strings.dart';
import '../models/models.dart';
import '../services/invoice_pdf.dart';

class HistoryScreen extends StatelessWidget {
  const HistoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('history'))),
      body: ListenableBuilder(
        listenable: Listenable.merge([app, app.repo]),
        builder: (context, _) {
          final u = app.user!;
          final list = app.repo.rides.where((r) {
            switch (u.activeMode) {
              case AppMode.rider:
                return r.riderId == u.id;
              case AppMode.driver:
                return r.driverId == u.id;
              case AppMode.business:
                return r.business && r.riderId == u.id;
            }
          }).toList();
          if (list.isEmpty) return Center(child: Text(t('noRides')));
          return ListView(children: [
            for (final r in list)
              ListTile(
                title: Text('${r.pickup.address} → ${r.dest.address}', maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text('${r.createdAt.toLocal().toString().substring(0, 16)} · ${t('s_${r.status.name}')}'),
                trailing: Text('${r.price.toStringAsFixed(0)} $currency'),
                onTap: r.status == RideStatus.completed ? () => shareInvoice(r, u.name) : null,
              ),
          ]);
        },
      ),
    );
  }
}
