import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/config.dart';
import '../core/strings.dart';
import '../models/models.dart';

/// Tableau de bord entreprise : courses marquées "entreprise" et dépenses.
class BusinessHome extends StatelessWidget {
  const BusinessHome({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('business'))),
      body: ListenableBuilder(
        listenable: app.repo,
        builder: (_, __) {
          final list = app.repo.rides.where((r) => r.business && r.riderId == app.user!.id).toList();
          final total = list.where((r) => r.status == RideStatus.completed).fold<double>(0, (s, r) => s + r.price);
          return ListView(children: [
            ListTile(title: Text(t('total')), trailing: Text('${total.toStringAsFixed(0)} $currency')),
            const Divider(),
            if (list.isEmpty) Padding(padding: const EdgeInsets.all(24), child: Text(t('noRides'))),
            for (final r in list)
              ListTile(
                title: Text('${r.pickup.address} → ${r.dest.address}', maxLines: 1, overflow: TextOverflow.ellipsis),
                subtitle: Text(t('s_${r.status.name}')),
                trailing: Text('${r.price.toStringAsFixed(0)} $currency'),
              ),
          ]);
        },
      ),
    );
  }
}
