import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../models/models.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('profile'))),
      body: ListenableBuilder(
        listenable: app,
        builder: (context, _) {
          final u = app.user!;
          return ListView(padding: const EdgeInsets.all(16), children: [
            ListTile(leading: const CircleAvatar(child: Icon(Icons.person)), title: Text(u.name), subtitle: Text(u.phone)),
            const Divider(),
            Text(t('mode')),
            const SizedBox(height: 8),
            SegmentedButton<AppMode>(
              showSelectedIcon: false,
              segments: [for (final m in u.roles) ButtonSegment(value: m, label: Text(t(m.name)))],
              selected: {u.activeMode},
              onSelectionChanged: (s) => app.switchMode(s.first),
            ),
            const SizedBox(height: 16),
            Text(t('language')),
            const SizedBox(height: 8),
            SegmentedButton<String>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: 'fr', label: Text('Français')),
                ButtonSegment(value: 'en', label: Text('English')),
                ButtonSegment(value: 'ar', label: Text('العربية')),
              ],
              selected: {app.lang},
              onSelectionChanged: (s) => app.setLang(s.first),
            ),
            SwitchListTile(title: Text(t('demo')), value: app.demoBot, onChanged: app.setBot),
            const Divider(),
            TextButton(onPressed: app.signOut, child: Text(t('logout'))),
          ]);
        },
      ),
    );
  }
}
