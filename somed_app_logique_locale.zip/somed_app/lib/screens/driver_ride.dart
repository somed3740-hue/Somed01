import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_state.dart';
import '../core/config.dart';
import '../core/strings.dart';
import '../models/models.dart';
import '../services/notifier.dart';

/// Déroulement de la course côté chauffeur.
class DriverRideScreen extends StatelessWidget {
  final String rideId;
  const DriverRideScreen({super.key, required this.rideId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('activeRide'))),
      body: ListenableBuilder(
        listenable: app.repo,
        builder: (context, _) {
          final r = app.repo.byId(rideId);
          if (r == null) return const SizedBox();
          final uid = app.user!.id;
          final next = switch (r.status) {
            RideStatus.accepted => (RideStatus.arrived, t('arrive')),
            RideStatus.arrived => (RideStatus.ongoing, t('start')),
            RideStatus.ongoing => (RideStatus.completed, t('finish')),
            _ => null,
          };
          final target = r.status == RideStatus.ongoing ? r.dest : r.pickup;
          return Padding(
            padding: const EdgeInsets.all(20),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(t('s_${r.status.name}'), style: Theme.of(context).textTheme.headlineSmall),
              const SizedBox(height: 12),
              ListTile(leading: const Icon(Icons.trip_origin, color: Colors.green), title: Text(r.pickup.address)),
              ListTile(leading: const Icon(Icons.location_on, color: Colors.red), title: Text(r.dest.address)),
              ListTile(
                leading: const Icon(Icons.payments_outlined),
                title: Text('${r.price.toStringAsFixed(0)} $currency · ${t(r.pay.name)}'),
              ),
              const Spacer(),
              if (r.status == RideStatus.offered)
                FilledButton(
                  onPressed: () => app.repo.accept(r.id, uid, app.user!.name),
                  child: Text(t('accept')),
                ),
              if (r.driverId == uid && !r.isFinal)
                OutlinedButton.icon(
                  icon: const Icon(Icons.navigation),
                  label: Text(t('navigate')),
                  onPressed: () => launchUrl(
                    Uri.parse('https://www.google.com/maps/dir/?api=1&destination=${target.lat},${target.lng}'),
                    mode: LaunchMode.externalApplication,
                  ),
                ),
              if (next != null && r.driverId == uid) ...[
                const SizedBox(height: 8),
                SizedBox(
                  width: double.infinity,
                  child: FilledButton(
                    onPressed: () {
                      app.repo.advance(r.id, next.$1);
                      Notifier.voice(next.$1);
                    },
                    child: Text(next.$2),
                  ),
                ),
              ],
            ]),
          );
        },
      ),
    );
  }
}
