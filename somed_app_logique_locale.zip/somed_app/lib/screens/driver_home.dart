import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/config.dart';
import '../core/strings.dart';
import '../models/models.dart';
import 'driver_ride.dart';

class DriverHome extends StatefulWidget {
  const DriverHome({super.key});
  @override
  State<DriverHome> createState() => _DriverHomeState();
}

class _DriverHomeState extends State<DriverHome> {
  final _hidden = <String>{};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('SOMED')),
      body: ListenableBuilder(
        listenable: Listenable.merge([app, app.repo]),
        builder: (context, _) {
          final uid = app.user!.id;
          final gains = app.repo.rides
              .where((r) => r.driverId == uid && r.status == RideStatus.completed)
              .fold<double>(0, (s, r) => s + r.price * (1 - commissionRate));
          return Column(children: [
            SwitchListTile(
              title: Text(app.driverOnline ? t('online') : t('offline')),
              subtitle: Text('${t('earnings')} : ${gains.toStringAsFixed(0)} $currency'),
              value: app.driverOnline,
              onChanged: app.setOnline,
            ),
            const Divider(height: 1),
            Expanded(
              child: !app.driverOnline
                  ? Center(child: Text(t('goOnline')))
                  : StreamBuilder(
                      stream: Stream.periodic(const Duration(seconds: 1)),
                      builder: (context, _) {
                        final offers = app.repo.offers(_hidden);
                        if (offers.isEmpty) return Center(child: Text(t('noOffers')));
                        return ListView(children: [
                          for (final r in offers)
                            Card(
                              margin: const EdgeInsets.all(12),
                              child: Padding(
                                padding: const EdgeInsets.all(12),
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text('${r.pickup.address} → ${r.dest.address}'),
                                  Text('${r.price.toStringAsFixed(0)} $currency · ${r.km.toStringAsFixed(1)} km · '
                                      '${r.offerExpiresAt!.difference(DateTime.now()).inSeconds} s'),
                                  Row(children: [
                                    TextButton(onPressed: () => setState(() => _hidden.add(r.id)), child: Text(t('decline'))),
                                    const Spacer(),
                                    FilledButton(
                                      onPressed: () {
                                        if (app.repo.accept(r.id, uid, app.user!.name)) {
                                          Navigator.push(context, MaterialPageRoute(builder: (_) => DriverRideScreen(rideId: r.id)));
                                        }
                                      },
                                      child: Text(t('accept')),
                                    ),
                                  ]),
                                ]),
                              ),
                            ),
                        ]);
                      },
                    ),
            ),
          ]);
        },
      ),
    );
  }
}
