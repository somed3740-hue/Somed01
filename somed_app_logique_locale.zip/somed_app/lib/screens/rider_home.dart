import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import '../core/app_state.dart';
import '../core/config.dart';
import '../core/strings.dart';
import '../models/models.dart';
import '../services/pricing.dart';
import 'map_picker.dart';
import 'rider_ride.dart';

class RiderHome extends StatefulWidget {
  const RiderHome({super.key});
  @override
  State<RiderHome> createState() => _RiderHomeState();
}

class _RiderHomeState extends State<RiderHome> {
  GoogleMapController? _map;
  Place? _pickup, _dest;
  VehicleType _v = VehicleType.eco;
  PayMethod _pay = PayMethod.cash;
  bool _biz = false;

  @override
  void initState() {
    super.initState();
    _locate();
  }

  LatLng get _here =>
      _pickup == null ? const LatLng(defaultLat, defaultLng) : LatLng(_pickup!.lat, _pickup!.lng);

  Future<void> _locate() async {
    var p = const LatLng(defaultLat, defaultLng);
    try {
      final perm = await Geolocator.requestPermission();
      if (perm != LocationPermission.denied && perm != LocationPermission.deniedForever) {
        final pos = await Geolocator.getCurrentPosition();
        p = LatLng(pos.latitude, pos.longitude);
      }
    } catch (_) {}
    final pl = await placeAt(p);
    if (!mounted) return;
    setState(() => _pickup = pl);
    _map?.animateCamera(CameraUpdate.newLatLngZoom(p, 15));
  }

  Future<void> _pick(bool dest) async {
    final r = await Navigator.push<Place>(
        context, MaterialPageRoute(builder: (_) => MapPicker(initial: _here)));
    if (r == null) return;
    setState(() => dest ? _dest = r : _pickup = r);
    if (_pickup != null && _dest != null) {
      final a = LatLng(_pickup!.lat, _pickup!.lng), b = LatLng(_dest!.lat, _dest!.lng);
      final sw = LatLng(a.latitude < b.latitude ? a.latitude : b.latitude,
          a.longitude < b.longitude ? a.longitude : b.longitude);
      final ne = LatLng(a.latitude > b.latitude ? a.latitude : b.latitude,
          a.longitude > b.longitude ? a.longitude : b.longitude);
      _map?.animateCamera(CameraUpdate.newLatLngBounds(LatLngBounds(southwest: sw, northeast: ne), 90));
    }
  }

  void _order(double km, double price) {
    final r = app.repo.create(
      riderId: app.user!.id, pickup: _pickup!, dest: _dest!, vehicle: _v,
      pay: _pay, km: km, price: price, business: _biz,
    );
    setState(() => _dest = null);
    Navigator.push(context, MaterialPageRoute(builder: (_) => RideScreen(rideId: r.id)));
  }

  @override
  Widget build(BuildContext context) {
    final ready = _pickup != null && _dest != null;
    final km = ready ? Pricing.km(_pickup!, _dest!) : 0.0;
    return ListenableBuilder(
      listenable: app.repo,
      builder: (_, __) {
        final active = app.repo.rides
            .where((r) => r.riderId == app.user!.id && !r.isFinal)
            .firstOrNull;
        return Stack(children: [
          GoogleMap(
            initialCameraPosition: CameraPosition(target: _here, zoom: 14),
            myLocationEnabled: true,
            myLocationButtonEnabled: false,
            zoomControlsEnabled: false,
            onMapCreated: (c) => _map = c,
            markers: {
              if (_pickup != null)
                Marker(
                  markerId: const MarkerId('p'),
                  position: LatLng(_pickup!.lat, _pickup!.lng),
                  icon: BitmapDescriptor.defaultMarkerWithHue(BitmapDescriptor.hueGreen),
                ),
              if (_dest != null)
                Marker(markerId: const MarkerId('d'), position: LatLng(_dest!.lat, _dest!.lng)),
            },
            polylines: {
              if (ready)
                Polyline(
                  polylineId: const PolylineId('r'), width: 4,
                  points: [LatLng(_pickup!.lat, _pickup!.lng), LatLng(_dest!.lat, _dest!.lng)],
                ),
            },
          ),
          SafeArea(
            child: Align(
              alignment: Alignment.topCenter,
              child: active == null
                  ? const SizedBox()
                  : Card(
                      margin: const EdgeInsets.all(12),
                      child: ListTile(
                        leading: const Icon(Icons.local_taxi),
                        title: Text(t('activeRide')),
                        subtitle: Text(t('s_${active.status.name}')),
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => RideScreen(rideId: active.id))),
                      ),
                    ),
            ),
          ),
          Align(
            alignment: Alignment.bottomCenter,
            child: Card(
              margin: const EdgeInsets.all(12),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  ListTile(
                    dense: true, leading: const Icon(Icons.trip_origin, color: Colors.green),
                    title: Text(_pickup?.address ?? '…', maxLines: 1, overflow: TextOverflow.ellipsis),
                    onTap: () => _pick(false),
                  ),
                  ListTile(
                    dense: true, leading: const Icon(Icons.location_on, color: Colors.red),
                    title: Text(_dest?.address ?? t('whereTo'), maxLines: 1, overflow: TextOverflow.ellipsis),
                    trailing: TextButton(onPressed: () => _pick(true), child: Text(t('setOnMap'))),
                    onTap: () => _pick(true),
                  ),
                  if (ready) ...[
                    SegmentedButton<VehicleType>(
                      showSelectedIcon: false,
                      segments: [
                        for (final v in VehicleType.values)
                          ButtonSegment(
                            value: v,
                            label: Text('${t(v.name)}\n${Pricing.estimate(v, km).toStringAsFixed(0)} $currency',
                                textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
                          ),
                      ],
                      selected: {_v},
                      onSelectionChanged: (s) => setState(() => _v = s.first),
                    ),
                    Row(children: [
                      Expanded(
                        child: DropdownButton<PayMethod>(
                          isExpanded: true, value: _pay,
                          items: [for (final p in PayMethod.values) DropdownMenuItem(value: p, child: Text(t(p.name)))],
                          onChanged: (p) => setState(() => _pay = p!),
                        ),
                      ),
                      if (app.user!.roles.contains(AppMode.business))
                        Row(children: [
                          Switch(value: _biz, onChanged: (v) => setState(() => _biz = v)),
                          Text(t('bizRide'), style: const TextStyle(fontSize: 12)),
                        ]),
                    ]),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton(
                        onPressed: () => _order(km, Pricing.estimate(_v, km)),
                        child: Text('${t('order')} · ${Pricing.estimate(_v, km).toStringAsFixed(0)} $currency'),
                      ),
                    ),
                  ],
                ]),
              ),
            ),
          ),
        ]);
      },
    );
  }
}
