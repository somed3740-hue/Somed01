import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../core/app_state.dart';
import '../core/config.dart';
import '../core/strings.dart';
import '../models/models.dart';
import '../services/invoice_pdf.dart';

/// Suivi de la course côté passager.
class RideScreen extends StatelessWidget {
  final String rideId;
  const RideScreen({super.key, required this.rideId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(t('activeRide'))),
      body: ListenableBuilder(
        listenable: app.repo,
        builder: (context, _) {
          final r = app.repo.byId(rideId);
          if (r == null) return const SizedBox();
          final waiting = r.status == RideStatus.searching || r.status == RideStatus.offered;
          return ListView(padding: const EdgeInsets.all(20), children: [
            Text(t('s_${r.status.name}'), style: Theme.of(context).textTheme.headlineSmall),
            if (waiting) const Padding(padding: EdgeInsets.symmetric(vertical: 16), child: LinearProgressIndicator()),
            const SizedBox(height: 12),
            ListTile(leading: const Icon(Icons.trip_origin, color: Colors.green), title: Text(r.pickup.address)),
            ListTile(leading: const Icon(Icons.location_on, color: Colors.red), title: Text(r.dest.address)),
            if (r.driverName != null)
              ListTile(leading: const Icon(Icons.person), title: Text(r.driverName!), subtitle: Text(t('driver'))),
            ListTile(
              leading: const Icon(Icons.payments_outlined),
              title: Text('${r.price.toStringAsFixed(0)} $currency · ${t(r.pay.name)}'),
              subtitle: Text('${r.km.toStringAsFixed(1)} km'),
              trailing: r.paid ? Chip(label: Text(t('paid'))) : null,
            ),
            const SizedBox(height: 12),
            if (r.status == RideStatus.completed && !r.paid)
              FilledButton(
                onPressed: () async {
                  if (await app.payment.pay(r)) app.repo.markPaid(r.id);
                },
                child: Text('${t('pay')} ${r.price.toStringAsFixed(0)} $currency'),
              ),
            if (r.status == RideStatus.completed) ...[
              const SizedBox(height: 8),
              Text(t('rate')),
              Row(children: [
                for (var i = 1; i <= 5; i++)
                  IconButton(
                    icon: Icon((r.rating ?? 0) >= i ? Icons.star : Icons.star_border, color: Colors.amber),
                    onPressed: () => app.repo.rate(r.id, i),
                  ),
              ]),
              OutlinedButton.icon(
                icon: const Icon(Icons.picture_as_pdf),
                label: Text(t('invoice')),
                onPressed: () => shareInvoice(r, app.user!.name),
              ),
            ],
            if (!r.isFinal && r.status != RideStatus.ongoing)
              TextButton(onPressed: () => app.repo.cancel(r.id), child: Text(t('cancel'))),
            if (r.status == RideStatus.ongoing || r.status == RideStatus.accepted || r.status == RideStatus.arrived)
              TextButton.icon(
                icon: const Icon(Icons.sos, color: Colors.red),
                label: Text(t('sos')),
                onPressed: () => launchUrl(Uri.parse('tel:$emergencyNumber')),
              ),
          ]);
        },
      ),
    );
  }
}
