import 'package:flutter/material.dart';

import '../core/app_state.dart';
import '../core/strings.dart';
import '../models/models.dart';
import 'business.dart';
import 'driver_home.dart';
import 'history.dart';
import 'profile.dart';
import 'rider_home.dart';

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (_, __) {
        final m = app.user!.activeMode;
        final home = switch (m) {
          AppMode.rider => const RiderHome(),
          AppMode.driver => const DriverHome(),
          AppMode.business => const BusinessHome(),
        };
        final pages = [KeyedSubtree(key: ValueKey(m), child: home), const HistoryScreen(), const ProfileScreen()];
        return Scaffold(
          body: pages[_i],
          bottomNavigationBar: NavigationBar(
            selectedIndex: _i,
            onDestinationSelected: (i) => setState(() => _i = i),
            destinations: [
              NavigationDestination(icon: const Icon(Icons.home_outlined), label: t('home')),
              NavigationDestination(icon: const Icon(Icons.receipt_long_outlined), label: t('history')),
              NavigationDestination(icon: const Icon(Icons.person_outline), label: t('profile')),
            ],
          ),
        );
      },
    );
  }
}
