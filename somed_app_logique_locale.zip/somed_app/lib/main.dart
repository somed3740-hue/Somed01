import 'package:app_links/app_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_stripe/flutter_stripe.dart';

import 'core/app_state.dart';
import 'core/config.dart';
import 'core/theme.dart';
import 'models/models.dart';
import 'screens/driver_ride.dart';
import 'screens/login.dart';
import 'screens/rider_ride.dart';
import 'screens/shell.dart';
import 'services/notifier.dart';

final navKey = GlobalKey<NavigatorState>();

void openRide(String id) {
  if (app.repo.byId(id) == null) return;
  final driver = app.user?.activeMode == AppMode.driver;
  navKey.currentState?.push(MaterialPageRoute(
    builder: (_) => driver ? DriverRideScreen(rideId: id) : RideScreen(rideId: id),
  ));
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (stripePublishableKey.isNotEmpty) Stripe.publishableKey = stripePublishableKey;
  await app.load();
  Notifier.onOpen = openRide;
  await Notifier.init();

  // Liens : https://votre-domaine/d/<idCourse> ouvre la course
  final links = AppLinks();
  void handle(Uri u) {
    if (u.pathSegments.length >= 2 && u.pathSegments.first == 'd') openRide(u.pathSegments[1]);
  }
  links.uriLinkStream.listen(handle);
  final first = await links.getInitialLink();
  runApp(const SomedApp());
  if (first != null) Future.delayed(const Duration(milliseconds: 600), () => handle(first));
}

class SomedApp extends StatelessWidget {
  const SomedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (_, __) => MaterialApp(
        navigatorKey: navKey,
        title: 'SOMED',
        debugShowCheckedModeBanner: false,
        theme: lightTheme,
        darkTheme: darkTheme,
        locale: Locale(app.lang),
        supportedLocales: const [Locale('fr'), Locale('en'), Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        home: app.user == null ? const LoginScreen() : const Shell(),
      ),
    );
  }
}
