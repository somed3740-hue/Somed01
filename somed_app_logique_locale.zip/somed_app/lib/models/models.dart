enum AppMode { rider, driver, business }

enum RideStatus { requested, searching, offered, accepted, arrived, ongoing, completed, cancelled, expired }

enum VehicleType { eco, comfort, moto }

enum PayMethod { cash, card, wallet }

T _en<T extends Enum>(List<T> v, Object? n, T d) =>
    v.firstWhere((e) => e.name == n, orElse: () => d);

class AppUser {
  String id, name, phone;
  Set<AppMode> roles;
  AppMode activeMode;
  AppUser({required this.id, required this.name, required this.phone, required this.roles, required this.activeMode});

  Map<String, dynamic> toJson() => {
        'id': id, 'name': name, 'phone': phone,
        'roles': roles.map((e) => e.name).toList(), 'mode': activeMode.name,
      };

  factory AppUser.fromJson(Map<String, dynamic> j) => AppUser(
        id: j['id'], name: j['name'], phone: j['phone'],
        roles: (j['roles'] as List).map((e) => _en(AppMode.values, e, AppMode.rider)).toSet(),
        activeMode: _en(AppMode.values, j['mode'], AppMode.rider),
      );
}

class Place {
  final String address;
  final double lat, lng;
  const Place(this.address, this.lat, this.lng);
  Map<String, dynamic> toJson() => {'a': address, 'lat': lat, 'lng': lng};
  factory Place.fromJson(Map<String, dynamic> j) => Place(j['a'], j['lat'], j['lng']);
}

class Ride {
  final String id, riderId;
  final Place pickup, dest;
  final VehicleType vehicle;
  final PayMethod pay;
  final double km, price;
  final bool business;
  final DateTime createdAt;
  RideStatus status;
  String? driverId, driverName;
  DateTime? offerExpiresAt;
  int? rating;
  bool paid;

  Ride({
    required this.id, required this.riderId, required this.pickup, required this.dest,
    required this.vehicle, required this.pay, required this.km, required this.price,
    required this.business, required this.createdAt,
    this.status = RideStatus.searching, this.driverId, this.driverName,
    this.offerExpiresAt, this.rating, this.paid = false,
  });

  bool get isFinal =>
      status == RideStatus.completed || status == RideStatus.cancelled || status == RideStatus.expired;

  Map<String, dynamic> toJson() => {
        'id': id, 'riderId': riderId, 'pickup': pickup.toJson(), 'dest': dest.toJson(),
        'vehicle': vehicle.name, 'pay': pay.name, 'km': km, 'price': price, 'business': business,
        'createdAt': createdAt.toIso8601String(), 'status': status.name,
        'driverId': driverId, 'driverName': driverName,
        'offerExpiresAt': offerExpiresAt?.toIso8601String(), 'rating': rating, 'paid': paid,
      };

  factory Ride.fromJson(Map<String, dynamic> j) => Ride(
        id: j['id'], riderId: j['riderId'],
        pickup: Place.fromJson(j['pickup']), dest: Place.fromJson(j['dest']),
        vehicle: _en(VehicleType.values, j['vehicle'], VehicleType.eco),
        pay: _en(PayMethod.values, j['pay'], PayMethod.cash),
        km: (j['km'] as num).toDouble(), price: (j['price'] as num).toDouble(),
        business: j['business'] ?? false, createdAt: DateTime.parse(j['createdAt']),
        status: _en(RideStatus.values, j['status'], RideStatus.expired),
        driverId: j['driverId'], driverName: j['driverName'],
        offerExpiresAt: j['offerExpiresAt'] == null ? null : DateTime.parse(j['offerExpiresAt']),
        rating: j['rating'], paid: j['paid'] ?? false,
      );
}
